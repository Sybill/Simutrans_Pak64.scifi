pak64.scifi Version 0.2 für Simutrans 112.x und The Iron Way r068

Was ist neu:

1. erste einfache Industriekette mit Tulabeerenfarm und Restaurant
2. erstes Kraftwerk Hyperraumzapfer
3. Frachtfahrzeug und Frachthalt für Schwebstraße und Röhrenbahn
4. Brücke und Tunnel für das Stromkabel
5. neue Sehenswürdigkeit (Foundationplaza) und Monument
6. nette kleine Ergänzungen und Verbesserungen von Hajo
7. Ergänzung der bisher fehlenden Symbole für Menüschaltflächen
8. Preise, Kosten und Geschwindigkeiten sind noch weitgehend willkürlich gewählt, es gibt ein umfassendes Balancing Konzept.
9. Keine Unterstützung für andere Sprachen als Deutsch und Englisch.
10. Es gibt weder Sound noch Musik.

Weiterhin gilt:

1. Es gibt bisher pro Verkehrsweg und Warenart nur ein Fahrzeug.
2. Es gibt noch keine Flughäfen und Flugzeuge.
3. Noch kein Waren- und Pakettransport per Schiff oder Kraftstrahlbahn möglich.
4. Es gibt bisher erst wenige Gebäude und Sehenswürdigkeiten.

----
pak64.scifi Version 0.12 für Simutrans 112.1 

Was ist neu:

1. Brücke und Signal für die Röhrenbahnstrecke, zwingende Wagenreihung für die Röhrenbahn
2. neues Fahrzeug für die Kraftstrahlstrecke von Saegge, zwingende Wagenreihung für Kraftstrahlgleiter
3. Pakettransporter und Paketstation für die Schwebstraße, Paketwagen für die Röhrenbahn, allgemeines Erweiterungsgebäude für Pakete und Fracht
4. Haltestellenliste (streetlist) in Deutsch und Englisch, verbesserte Texte und erweiterte Stadtliste
5. kleinere Korrekturen und Änderungen

Weiterhin gilt:

1. Es gibt bisher pro Verkehrsweg und Warenart nur ein Fahrzeug.
2. Es gibt noch keine Flughäfen und Flugzeuge.
3. Es gibt noch keine Fabriken und Kraftwerke.
4. Es gibt bisher erst wenige Gebäude und Sehenswürdigkeiten.
5. Einige Menübuttons sind leer, dienen als Platzhalter und werden erst später erstellt. Manche funktionieren allerdings bereits (wie z. B. Wald aufforsten).
6. Preise, Kosten, Geschwindigkeiten etc. sind bisher rein willkürlich gewählt oder direkt aus den Vorlagen entnommen worden, es gibt bisher noch kein Konzept dafür.
7. Keine Unterstützung für andere Sprachen als Deutsch und Englisch.
8. Es gibt weder Sound noch Musik (wird es von meiner Seite auch nicht geben, da ich Simutrans sowieso immer ohne sound spiele).

----
pak64.scifi Version 0.11 für Simutrans 111 

Was ist neu:

1. Depot und Haltestelle für die Röhrenbahnstrecke, die Strecke selbst wurde leicht modifiziert
2. Demofahrzeug für die Röhrenbahnstrecke (wird noch verbessert)
3. Stromleitung (noch nicht verwendbar, da weiterhin keine Industrie und Kraftwerke vorhanden, zudem gibt es noch Probleme bei der Kreuzung anderer Wegarten)
4. drei neue Gebäude
5. Kleinere Korrekturen und Änderungen

Weiterhin gilt:

1. Es gibt bisher pro Verkehrsweg nur ein Fahrzeug.
2. Es gibt noch keine Flughäfen und Flugzeuge.
3. Es gibt noch keine Fabriken und Kraftwerke.
4. Es gibt bisher erst wenige Gebäude und Sehenswürdigkeiten.
5. Einige Menübuttons sind leer, dienen als Platzhalter und werden erst später erstellt. Manche funktionieren allerdings bereits (wie z. B. Wald aufforsten).
6. Preise, Kosten, Geschwindigkeiten etc. sind bisher rein willkürlich gewählt oder direkt aus den Vorlagen entnommen worden, es gibt bisher noch kein Konzept dafür.
7. Es gibt bisher keine Übersetzungen, mit dem ganzen Bereich "text" habe ich mich bisher noch nicht beschäftigt.
8. Es gibt weder Sound noch Musik (wird es von meiner Seite auch nicht geben, da ich Simutrans sowieso immer ohne sound spiele).

----
pak64.scifi Version 0.1 für Simutrans 111 

Das Pak verwendet folgende original Grafiken aus dem pak.64 Standard:
texture-lightmap
texture-shore
texture-slope
sowie einige Cursor, Symbole und Buttons,
ebenso einige Buttons aus der menu_buttons.png für pak128 (->http://forum.simutrans.com/index.php?topic=9656.msg90806#msg90806),
und eines der neuen money-icons von Fabio.

ACHTUNG
Bein Drücken einer unerwarteten Taste (z. B. aus dem Nummernblock) beendet sich Simutrans überraschend, statt die Tastaturhilfe einzublenden. Ich habe bisher noch nicht herausgefunden, woran das liegt.

