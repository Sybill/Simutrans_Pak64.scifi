pak64.scifi Version 0.2 für Simutrans 112.x und The Iron Way r068

What's new:

1. first simple industry chain with tulaberry farm and restaurant
2. first power station hyperspace tapper
3. freight vehicle and freight stop for hoverroad and tube rail
4. bridge and tunnel for power cable
5. new attraction and monument
6. some nice additions and changes from Hajo
7. added symbols for some menu buttons
8. Prices, costs and speeds are still chosen arbitrarily, there is a no balancing concept yet.
9. There are no translations for other languages than english or german.
10.  There is no sound or music.

In addition:

1. So far there is only one vehicle for each transport system and goods type.
2. There are no airports and air planes.
3. No goods and packet transport possible by boat or powerbeam.
4. So far there are only a few buildings and curiosities.

----
pak64.scifi Version 0.12 for Simutrans 112.1

What's new:

1. Bridge and signal for tube rail track, mandatory car sequence for tube rail
2. New vehicle from Saegge for powerbeam, mandatory car sequence for powerbeam
3. Parcel vehicle and parcel station for hoverroad, parcel wagon for tube rail, extension building for freight and parcel
4. Streetlist in english and german, extended citylist, and improved texts in english and german
5. Minor fixes and modifications

In addition:

1. So far there is only one vehicle for each transport system and goods type.
2. There are no factories and power plants.
3. There are no airports and air planes.
4. So far there are only a few buildings and curiosities.
5. Some menu buttons are empty, serving as a place holder and will be created later. Some work, however, already (such as reforestation Forest).
6. Prices, costs, speeds etc. are purely arbitrary chosen or been taken directly from the templates, there is as yet no concept for it.
7. There are no translations for other languages than english or german.
8. There is no sound or music.

----
pak64.scifi Version 0.11 for Simutrans 111 

What's new:

1. Depot and railway station for the tube rail, the track itself was modified slightly
2. Demo vehicle for the tube railway (to be improved)
3. Power line (not used yet due to lack of industry and power plants, it also has problems with crossing other Way types)
4. Three new buildings
5. Minor fixes and modifications

In addition:

1. So far there are only one vehicle for each transport system.
2. There are no factories and power plants.
3. There are no airports and air planes.
4. So far there are only a few buildings and curiosities.
5. Some menu buttons are empty, serving as a place holder and will be created later. Some work, however, already (such as reforestation Forest).
6. Prices, costs, speeds etc. are purely arbitrary chosen or been taken directly from the templates, there is as yet no concept for it.
7. There are no translations, with the whole field "text" I have not been involved yet.
8. There is no sound or music.

----
pak64.scifi version 0.1 for Simutrans 111

The Pak uses the following original graphics from the standard pak.64:
texture-lightmap
texture-shore
texture-slope
and some cursors, icons and buttons,
just a few buttons from the menu_buttons.png for pak128 (->http://forum.simutrans.com/index.php?topic=9656.msg90806#msg90806),
and one of the new money-icons of Fabio.

ATTENTION
Pressing an unexpected button  (e.g., from the number pad) terminates Simutrans surprisingly, instead of bring up the keyboard help. I have not found out yet why this is.
