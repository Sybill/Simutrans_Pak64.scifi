pak64.scifi Version 0.11 für Simutrans 111 

Was ist neu:

1. Depot und Haltestelle für die Röhrenbahnstrecke, die Strecke selbst wurde leicht modifiziert
2. Demofahrzeug für die Röhrenbahnstrecke (wird noch verbessert)
3. Stromleitung (noch nicht verwendbar, da weiterhin keine Industrie und Kraftwerke vorhanden, zudem gibt es noch Probleme bei der Kreuzung anderer Wegarten)
4. drei neue Gebäude
5. Kleinere Korrekturen und Änderungen

Weiterhin gilt:

1. Es gibt bisher pro Verkehrsweg nur ein Fahrzeug.
2. Es gibt noch keine Flughäfen und Flugzeuge.
3. Es gibt noch keine Fabriken und Kraftwerke.
4. Es gibt bisher erst wenige Gebäude und Sehenswürdigkeiten.
5. Einige Menübuttons sind leer, dienen als Platzhalter und werden erst später erstellt. Manche funktionieren allerdings bereits (wie z. B. Wald aufforsten).
6. Preise, Kosten, Geschwindigkeiten etc. sind bisher rein willkürlich gewählt oder direkt aus den Vorlagen entnommen worden, es gibt bisher noch kein Konzept dafür.
7. Es gibt bisher keine Übersetzungen, mit dem ganzen Bereich "text" habe ich mich bisher noch nicht beschäftigt.
8. Es gibt weder Sound noch Musik (wird es von meiner Seite auch nicht geben, da ich Simutrans sowieso immer ohne sound spiele).

----
pak64.scifi Version 0.1 für Simutrans 111 

Das Pak verwendet folgende original Grafiken aus dem pak.64 Standard:
texture-lightmap
texture-shore
texture-slope
sowie einige Cursor, Symbole und Buttons,
ebenso einige Buttons aus der menu_buttons.png für pak128 (->http://forum.simutrans.com/index.php?topic=9656.msg90806#msg90806),
und eines der neuen money-icons von Fabio.

ACHTUNG
Bein Drücken einer unerwarteten Taste (z. B. aus dem Nummernblock) beendet sich Simutrans überraschend, statt die Tastaturhilfe einzublenden. Ich habe bisher noch nicht herausgefunden, woran das liegt.

