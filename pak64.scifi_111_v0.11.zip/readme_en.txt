pak64.scifi Version 0.11 für Simutrans 111 

What's new:

1. Depot and railway station for the tube rail, the track itself was modified slightly
2. Demo vehicle for the tube railway (to be improved)
3. Power line (not used yet due to lack of industry and power plants, it also has problems with crossing other Way types)
4. Three new buildings
5. Minor fixes and modifications

In addition:

1. So far there are only one vehicle for each transport system.
2. There are no factories and power plants.
3. There are no airports and air planes.
4. So far there are only a few buildings and curiosities.
5. Some menu buttons are empty, serving as a place holder and will be created later. Some work, however, already (such as reforestation Forest).
6. Prices, costs, speeds etc. are purely arbitrary chosen or been taken directly from the templates, there is as yet no concept for it.
7. There are no translations, with the whole field "text" I have not been involved yet.
8. There is no sound or music.

----
pak64.scifi version 0.1 for Simutrans 111

The Pak uses the following original graphics from the standard pak.64:
texture-lightmap
texture-shore
texture-slope
and some cursors, icons and buttons,
just a few buttons from the menu_buttons.png for pak128 (->http://forum.simutrans.com/index.php?topic=9656.msg90806#msg90806),
and one of the new money-icons of Fabio.

ATTENTION
Pressing an unexpected button  (e.g., from the number pad) terminates Simutrans surprisingly, instead of bring up the keyboard help. I have not found out yet why this is.
