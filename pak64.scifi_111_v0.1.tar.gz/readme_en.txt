pak64.scifi version 0.1 for Simutrans 111

The Pak uses the following original graphics from the standard pak.64:
texture-lightmap
texture-shore
texture-slope
and some cursors, icons and buttons,
just a few buttons from the menu_buttons.png for pak128 (->http://forum.simutrans.com/index.php?topic=9656.msg90806#msg90806),
and one of the new money-icons of Fabio.

The pak itself is only very limited playable, for the following reasons:

1. So far there are only one vehicle for each transport system.
2. The tube railway (rail replacement) is still under construction, there are no depots, stations and vehicles.
3. There are no factories, power plants and power lines.
4. There are no airports and air planes.
5. So far there are only a few buildings and curiosities.
6. Some menu buttons are empty, serving as a place holder and will be created later. Some work, however, already (such as reforestation Forest).
7. Prices, costs, speeds etc. are purely arbitrary chosen or been taken directly from the templates, there is as yet no concept for it.
8. There are no translations, with the whole field "text" I have not been involved yet.
9. There is no sound or music.

ATTENTION
Pressing an unexpected button  (e.g., from the number pad) terminates Simutrans surprisingly, instead of bring up the keyboard help. I have not found out yet why this is.
